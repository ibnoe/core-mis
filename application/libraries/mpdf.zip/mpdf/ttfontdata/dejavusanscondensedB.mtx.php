<?php
$name='DejaVuSansCondensed-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 262148,
  'FontBBox' => '[-962 -415 1778 1174]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile='C:/xampp2/htdocs/amartha/application/libraries/mpdf/ttfonts/DejaVuSansCondensed-Bold.ttf';
$TTCfontID='0';
$originalsize=545712;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusanscondensedB';
$panose=' 0 0 2 b 8 6 3 6 4 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>